package org.banking.sbm.loanservice.constants;

public interface Queries {
    String ACCOUNTDETAILS = "select account_balance, customer_id, cibil_score from account details where account_id = ?";
    String LOANENRTY= "INSERT INTO loan_details (loan_id, account_id, loan_amount, loan_tenure, loan_exp_date, loan_status, loan_reason, loan_approve_date, customer_id) values (?,?,?,?,?,?,?,?,?)";
    String LOANDETAILS= "select * from loan_details where customer_id = ?";
    String LOANDETAIL= "select * from loan_details where customer_id = ? and loan_id = ?";
}
