package org.banking.sbm.acoountservices.repository;

import org.banking.sbm.acoountservices.constant.Queries;
import org.banking.sbm.acoountservices.model.AccountDetails;
import org.banking.sbm.acoountservices.model.AccountStatement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountDetailsRepo extends JpaRepository<AccountDetails, Long> {

    @Query(value = Queries.ACCOUNTDETAILS, nativeQuery = true)
    AccountDetails accDetails (String accpunt_id);

    @Query(value = Queries.DEBITCREDIT, nativeQuery = true)
    void debitCredit (String balance, String account_id);

}
