package org.banking.sbm.acoountservices.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter @Setter @ToString
@Entity
@Table(name="account_statement")
public class AccountStatement {
    @Id
    @Column(name="transaction_id")
    private String transaction_id;
    @Column(name="account_id")
    private String account_id;
    @Column(name="account_balance")
    private String account_balance;
    @Column(name="customer_id")
    private String customer_id;
    @Column(name="transaction_date")
    private Date trasaction_date;
    @Column(name="transaction_amount")
    private String transaction_amount;

}
