package org.banking.sbm.acoountservices.repository;

import org.banking.sbm.acoountservices.constant.Queries;
import org.banking.sbm.acoountservices.model.AccountDetails;
import org.banking.sbm.acoountservices.model.AccountStatement;
import org.banking.sbm.acoountservices.model.CreditDebitRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface AccountStatementRepo extends JpaRepository<AccountStatement, Long> {
    @Query(value = Queries.STATEMENT, nativeQuery = true)
    List<AccountStatement> accStatement (String account_id);

    @Query(value = Queries.STATEMENTINTIMEPERIOD, nativeQuery = true)
    List<AccountStatement> accStatementInTimePeriod (String accountId, Date startDate, Date endDate, String sortOrder);

    @Query(value = Queries.TRANSACTIONENTRY, nativeQuery = true)
    void transactionEntry (String trasaction_id, String account_banalce, String customer_id, Date tranactionDate, String transaction_amount, String accId);
}
