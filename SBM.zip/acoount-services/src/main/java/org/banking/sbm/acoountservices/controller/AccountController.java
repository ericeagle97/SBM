package org.banking.sbm.acoountservices.controller;

import org.banking.sbm.acoountservices.model.CreditDebitRequest;
import org.banking.sbm.acoountservices.service.CreditDebitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api")
public class AccountController {

    @Autowired
    @Qualifier("cdrImpl")
    private CreditDebitService cds;

    @PutMapping("/accounts/{id}")
    public ResponseEntity<Object> creditDebitRequest(@PathVariable("id") String id, @RequestBody CreditDebitRequest cdr) {
        return cds.creditDebitRequest(cdr);
    }

    @GetMapping("/accounts/{id}/statement")
    public ResponseEntity<Object> accountStatement(@PathVariable("id") String id, @RequestParam(name = "start_date", required = false) String startDate, @RequestParam(name = "end_date", required = false) String endDate, @RequestParam(name = "sort", required = false) String sortOrder) throws Exception {
        return cds.accountStatement(id, startDate, endDate, sortOrder);
    }
}
