package org.banking.sbm.acoountservices.service.impl;

import org.banking.sbm.acoountservices.model.AccountDetails;
import org.banking.sbm.acoountservices.model.AccountStatement;
import org.banking.sbm.acoountservices.model.CreditDebitRequest;
import org.banking.sbm.acoountservices.repository.AccountDetailsRepo;
import org.banking.sbm.acoountservices.repository.AccountStatementRepo;
import org.banking.sbm.acoountservices.service.CreditDebitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service("cdrImpl")
public class CreditDebitServiceImpl implements CreditDebitService {


    @Autowired
    public AccountStatementRepo acrepo;

    @Autowired
    public AccountDetailsRepo accDetRepo;

    @Override
    public ResponseEntity<Object> creditDebitRequest(CreditDebitRequest cdr) {
        String requestedTranscAmount = cdr.getAmount();
        BigDecimal reqTranscAmount = new BigDecimal(requestedTranscAmount);
        AccountDetails statement = accDetRepo.accDetails(cdr.getAccount_id());
        String presentBalance = statement.getAccount_balance();
        BigDecimal availableBalance = new BigDecimal(presentBalance);
        BigDecimal finalBalance;
        if(statement != null) {
            SimpleDateFormat formatter = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
            String transaction_id = cdr.getAccount_id() + formatter.format(new Date());
            if(cdr.getType().equalsIgnoreCase("debit")) {
               if(availableBalance.compareTo(reqTranscAmount) > -1) {
                   finalBalance = availableBalance.subtract(reqTranscAmount);
                   statement.setAccount_balance(finalBalance.toString());
                   accDetRepo.debitCredit(finalBalance.toString(), cdr.getAccount_id());
                   acrepo.transactionEntry(transaction_id, finalBalance.toString(), statement.getCustomer_id(), new Date(), cdr.getAmount(), cdr.getAccount_id());
                   return ResponseEntity.ok().body(statement);
               } else {
                   return ResponseEntity.badRequest().body("Insufficient balance");
               }
            } else  if (cdr.getType().equalsIgnoreCase("credit")) {
                finalBalance = availableBalance.add(reqTranscAmount);
                accDetRepo.debitCredit(finalBalance.toString(), cdr.getAccount_id());
                acrepo.transactionEntry(transaction_id, finalBalance.toString(), statement.getCustomer_id(), new Date(), cdr.getAmount(), cdr.getAccount_id());
                statement.setAccount_balance(finalBalance.toString());
                return ResponseEntity.ok().body(statement);
            }
        }
        return ResponseEntity.badRequest().body("Invalid Request");
    }

    @Override
    public ResponseEntity<Object> accountStatement(String id, String startDate, String endDate, String sortOrder) throws ParseException {
        List<AccountStatement> acStatement = null;
        if(startDate != null && endDate != null && sortOrder != null) {
            Date sd =new SimpleDateFormat("dd-MM-yyyy").parse(startDate);
            Date ed =new SimpleDateFormat("dd-MM-yyyy").parse(endDate);
             acStatement = acrepo.accStatementInTimePeriod(id, sd, ed, sortOrder);
        } else {
            acStatement = acrepo.accStatement(id);
        }
        if(acStatement != null) {
            return ResponseEntity.ok(acStatement);
        } else {
            return  ResponseEntity.badRequest().body("Invalid account id");
        }
    }
}
