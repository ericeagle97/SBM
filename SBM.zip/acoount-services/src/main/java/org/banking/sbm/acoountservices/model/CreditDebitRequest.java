package org.banking.sbm.acoountservices.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;

@Getter @Setter

public class CreditDebitRequest {

    private String account_id;
    private String amount;
    private String type;

}
