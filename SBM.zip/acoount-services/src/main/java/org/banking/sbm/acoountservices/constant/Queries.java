package org.banking.sbm.acoountservices.constant;

public interface Queries {


    String DEBITCREDIT= "update account_details set account_balance = ? where account_id = ?";
    String STATEMENT= "select transaction_id, account_balance,customer_id, transaction_date, transaction_amount from account_statement where account_id = ?";
    String ACCOUNTDETAILS= "select account_balance, customer_id, cibil_score from account details where account_id = ?";
    String STATEMENTINTIMEPERIOD = "select transaction_id, account_balance,customer_id, transaction_date, transaction_amount from account_statement where account_id = ? and transaction_date between ? and ? order by transaction_date ?";
    String TRANSACTIONENTRY = "insert into account_statement(transaction_id, account_balance,customer_id, transaction_date, transaction_amount, account_id) values (?,?,?,?,?,?)";

}
