package org.banking.sbm.acoountservices.service;

import org.banking.sbm.acoountservices.model.CreditDebitRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.text.ParseException;


public interface CreditDebitService {
     ResponseEntity<Object> creditDebitRequest(CreditDebitRequest cdr);
     ResponseEntity<Object> accountStatement(String id, String startDate, String endDate, String sortOrder) throws ParseException;
}
