package org.banking.sbm.notificationservice.controller;

import org.banking.sbm.notificationservice.model.NotificationDetails;
import org.banking.sbm.notificationservice.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class NotificationController {

    @Autowired
    @Qualifier("notifImpl")
    private NotificationService nfs;

    @PostMapping("/notification/customer/{csid}")
    public ResponseEntity<Object> pushNotification(@PathVariable( "csid") String csid, @RequestBody NotificationDetails nfd) {
        nfd.setCutomer_id(csid);
        return nfs.pushNotification(nfd);
    }

    @GetMapping({"/customer/{csid}", "/customer/{csid}/notification/{nfid}" })
    public ResponseEntity<Object> getNotification(@PathVariable( "csid") String csid, @PathVariable( name = "nfid", required = false) String nfid) {
        return nfs.getNotification(csid, nfid);
    }
}
