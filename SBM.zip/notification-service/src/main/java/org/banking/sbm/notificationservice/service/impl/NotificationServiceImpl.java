package org.banking.sbm.notificationservice.service.impl;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.banking.sbm.notificationservice.model.NotificationDetails;
import org.banking.sbm.notificationservice.repository.NotificationRepo;
import org.banking.sbm.notificationservice.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("notifImpl")
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationRepo nfr;

    @Autowired
    private Producer<String, String> kp;

    public ResponseEntity<Object> pushNotification(NotificationDetails nfd) {
        nfr.addNotifdetails(nfd.getCutomer_id(), nfd.getId(), nfd.getEmail_address(), nfd.getPhone(), nfd.getMessage());
        ProducerRecord<String, String> producerRecord = new ProducerRecord<>("second_topic", nfd.toString());
        List<Integer> exception = new ArrayList<>();
        kp.send(producerRecord, (recordMetadata, e)  -> {
            if (e != null) {
                System.out.println(" Exception in prducing to kafka :: " + e);
                exception.add(1);
            }
        });
        if(exception.size() > 0) {
            return ResponseEntity.internalServerError().body("unable to push to kafka");
        }
        return ResponseEntity.ok("successfully sent notification");
    }

    public ResponseEntity<Object> getNotification(String csid, String id){
        if(id != null) {
            NotificationDetails notifDetails = nfr.notifdetails(csid, id);
            if (notifDetails != null) {
                return ResponseEntity.ok(notifDetails);
            } else {
                return ResponseEntity.badRequest().body("Invalid Request");
            }
        } else {
            List<NotificationDetails> notifDetails = nfr.allNotifdetails(csid);
            if (notifDetails != null) {
                return ResponseEntity.ok(notifDetails);
            } else {
                return ResponseEntity.badRequest().body("Invalid Request");
            }
        }
    }
}
