package org.banking.sbm.notificationservice.repository;

import org.banking.sbm.notificationservice.constants.Queries;
import org.banking.sbm.notificationservice.model.NotificationDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepo extends JpaRepository<NotificationDetails, Long> {

    @Query(value = Queries.GETNOTIFICATION, nativeQuery = true)
    NotificationDetails notifdetails(String csid, String notifId);

    @Query(value = Queries.GETALLNOTIFICATION, nativeQuery = true)
    List<NotificationDetails> allNotifdetails(String csid);

    @Query(value = Queries.ADDNOTIFICATION, nativeQuery = true)
    void addNotifdetails(String csid, String notifId, String emailId, String mobileNo, String message);


}
