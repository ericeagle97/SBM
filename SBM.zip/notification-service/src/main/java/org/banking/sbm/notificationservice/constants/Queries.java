package org.banking.sbm.notificationservice.constants;

public interface Queries {

    String ADDNOTIFICATION = "INSERT INTO notification_details (customer_id, id, email_id, mobile_no, message) values (?,?,?,?,?)";
    String GETNOTIFICATION = "select id, email_id, mobile_no, message from notification_details where customer_id = ? and id = ?";
    String GETALLNOTIFICATION = "select id, email_id, mobile_no, message from notification_details where customer_id = ?";


}
