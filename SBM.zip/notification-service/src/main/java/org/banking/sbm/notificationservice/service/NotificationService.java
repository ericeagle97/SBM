package org.banking.sbm.notificationservice.service;

import org.banking.sbm.notificationservice.model.NotificationDetails;
import org.springframework.http.ResponseEntity;

public interface NotificationService {

    ResponseEntity<Object> pushNotification(NotificationDetails notificationDetails);
    ResponseEntity<Object> getNotification(String csId, String notif_id);
}
